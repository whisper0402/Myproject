OkHttp DNS over HTTPS Implementation
====================================

This module is an experimental implementation of DNS over HTTPS using OkHttp.
API is not considered stable and may change at any time.

### Download

```kotlin
testImplementation("com.squareup.okhttp3:okhttp-dnsoverhttps:4.7.2")
```
