# Module okhttp

An HTTP+HTTP/2 client for Android and Java applications.
